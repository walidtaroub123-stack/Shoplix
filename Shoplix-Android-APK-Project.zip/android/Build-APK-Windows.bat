@echo off
chcp 65001 >nul
where gradle >nul 2>nul
if errorlevel 1 (
  echo لم يتم العثور على Gradle. افتح المشروع في Android Studio وثبّت Gradle و Android SDK Platform 37.
  pause
  exit /b 1
)
gradle assembleDebug
if errorlevel 1 (
  echo فشل البناء. راجع رسائل Gradle و Android SDK.
  pause
  exit /b 1
)
echo تم إنشاء APK داخل app\build\outputs\apk\debug\app-debug.apk
pause
